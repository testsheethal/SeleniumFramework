package ObjectRepository;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import java.lang.Exception;

import org.apache.commons.io.FileUtils;
import org.junit.BeforeClass;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.*;
import java.net.URL;
import java.security.spec.KeySpec;

import EnvirnomentSetup.ConfigReader;
import freemarker.debug.Debugger;

import java.net.MalformedURLException;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Base {

	protected RemoteWebDriver remoteDriver = null;
	public static WebDriver driver;
	public String browswerName = null;
    static ConfigReader reader  = new ConfigReader();
	private static String secretKey = reader.getSecretKey();
    private static String salt =reader.getSalt();

	public WebDriver initialiseDriver() throws MalformedURLException {
		ConfigReader reader = new ConfigReader();
		String browswerName = System.getProperty("Browser");
		if (browswerName.equals("Chrome")) {

			/*System.setProperty("remoteWebDriverUrl", "http://137.182.192.253:4444/wd/hub");

			System.out.println("Inside chrome:");

			String url = System.getProperty("remoteWebDriverUrl");

			ChromeOptions options = new ChromeOptions();

			options.setHeadless(true);
			options.addArguments("window-size=1920,1080");
			

			options.addArguments("--no-sandbox");

			remoteDriver = new RemoteWebDriver(new URL(url), options);
*/

            System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\b.n.3\\\\Downloads\\\\chromedriver_win32\\\\chromedriver.exe");
            driver = new ChromeDriver();
            //DesiredCapabilities capability = DesiredCapabilities.chrome();
            //capability.setBrowserName("chrome");
            //capability.setPlatform(Platform.LINUX);
            System.out.println("Inside chrome:");
            driver.manage().deleteAllCookies();
		} else if (browswerName.equals("Firefox")) 
		{
			/*System.out.println("firefox");
			remoteDriver = new FirefoxDriver();
			System.setProperty("remoteWebDriverUrl", "http://137.182.192.253:4444/wd/hub");
			DesiredCapabilities capability = DesiredCapabilities.chrome();
			capability.setBrowserName("firefox");
			capability.setPlatform(Platform.LINUX);
			System.out.println("Inside FF:");
			String url = System.getProperty("remoteWebDriverUrl");
			remoteDriver = new RemoteWebDriver(new URL(url), capability);*/
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\b.n.3\\Downloads\\geckodriver-v0.24.0-win64\\geckodriver.exe");
		     FirefoxOptions firefoxOptions = new FirefoxOptions();
             firefoxOptions.addPreference("network.proxy.type", ProxyType.AUTODETECT.ordinal());
              driver = new FirefoxDriver(firefoxOptions);

		} else if (browswerName.equals("IE")) {
			System.setProperty("webdriver.ie.driver",
					"C:\\Users\\b.n.3\\EndToEndDigitalization\\Drivers\\IEDriverServer.exe");
			remoteDriver = new InternetExplorerDriver();
		} else if (browswerName.equals("safari")) {
			// code for safari
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("before return" + driver);
		return driver;

	}
	
	
	public static void highLightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {

			System.out.println(e.getMessage());
		}

		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element);

	}

	public static void waitForPage() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public WebDriver closeBroswer() {
		remoteDriver.close();
		return remoteDriver;

	}
public void getScreenshot(String result) {
		// TODO Auto-generated method stub
		File src =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File(".//test-output/"+result+"screenshot.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
public static String decrypt(String strToDecrypt, String secret) {
	try {
		byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		IvParameterSpec ivspec = new IvParameterSpec(iv);

		SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
		KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
		SecretKey tmp = factory.generateSecret(spec);
		SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
		cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
		return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
	} catch (Exception e) {
		System.out.println("Error while decrypting: " + e.toString());
	}
	return null;
}

}
