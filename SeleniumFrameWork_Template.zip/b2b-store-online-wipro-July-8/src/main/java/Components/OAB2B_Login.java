package Components;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.text.StyleConstants.CharacterConstants;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.CharMatcher;

import EnvirnomentSetup.ConfigReader;
import ObjectRepository.Base;
import Resources.JSONLoginReader;
import Resources.JSONReader;

public class OAB2B_Login {
	public static WebDriver driver;

	public static Logger log = LogManager.getLogger(OAB2B_Login.class.getName());
	public static JSONReader jreader = null;
	public static JSONLoginReader ljreader = null;
	JavascriptExecutor js = null;
	static ConfigReader reader = new ConfigReader();
	private static String secretKey = reader.getSecretKey();

	public OAB2B_Login(WebDriver driver) throws IOException {

		this.driver = driver;
		log.info("Chrome Browser driver started");
		reader = new ConfigReader();
		jreader = new JSONReader();
		ljreader = new JSONLoginReader();
		js = (JavascriptExecutor) driver;
		try {
			jreader.Reader();
			ljreader.Reader();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public WebElement getEmailB2b() {

		return driver.findElement(By.xpath(reader.getEmailb2b()));
	}

	public WebElement getPassword() {
		log.info("Got Password");
		return driver.findElement(By.xpath(reader.getpassword()));
	}

	public WebElement getGO() {
		log.info("Clicked on go");
		return driver.findElement(By.xpath(reader.getEnter()));
	}

	public WebElement getcookiePopUp() {
		log.info("Clicked on go");
		return driver.findElement(By.xpath(reader.cookiePopUp()));
	}

	public void Login() throws Exception

	{

		log.info("Logged into Application !!!!!!");

		driver.get(jreader.productmap.get("URL"));

		WebDriverWait wait = new WebDriverWait(driver, 120);

		Thread.sleep(15000);

		try {

			getcookiePopUp().click();

		} catch (NoSuchElementException e) {

			// TODO Auto-generated catch block

			// e.printStackTrace();

		}

		try {

			if (getEmailB2b().isDisplayed())

			{
				String email = ljreader.loginmap.get("Email");
				System.out.println("Email : " + email);
				getEmailB2b().sendKeys(email);

				Thread.sleep(15000);

				String encodePassword = JSONLoginReader.loginmap.get("Password");

				String decryptedString = Base.decrypt(encodePassword, secretKey);

				decryptedString = CharMatcher.INVISIBLE.removeFrom(decryptedString);

				getPassword().sendKeys(decryptedString);

				js.executeScript("arguments[0].click();", getGO());

			}

		} catch (NoSuchElementException e) {

			// TODO Auto-generated catch block

			// e.printStackTrace();

		}

		log.info("Exist from Login Method!!!!!!");

		System.out.println("Successfully Credentials entered !!!");

	}
}