package Resources;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.IReporter;

import EnvirnomentSetup.ConfigReader;

public class JSONReader {

	public static String filepath = null;
	public static Map<String, String> productmap = new HashMap<String, String>();
	public static ArrayList productName = new ArrayList();
	public static ConfigReader reader;
	public static String Region;
	public static String Env;
	@SuppressWarnings("unchecked")
	public static void Reader() {
//JSON parser object to parse read file
		reader = new ConfigReader();
		JSONParser jsonParser = new JSONParser();
		Env = System.getProperty("Env");
		Region = System.getProperty("Region");
		filepath = Env + "_" + Region;
		System.out.println("Env : Region : Market: " + filepath);

		try {

			filepath = filepath + ".json";
			FileReader reader = new FileReader(".//TestData/" + filepath);
			Object obj = jsonParser.parse(reader);

			JSONArray productList = (JSONArray) obj;
			/* System.out.println(productList); */

			// Iterate over product array
			productList.forEach(emp -> parseProductObject((JSONObject) emp));
			/* System.out.println("Reading JSON" + productName.size()); */
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

	private static void parseProductObject(JSONObject product) {
//Get product object within list
		JSONObject productObject = (JSONObject) product.get("Market");

		productmap.put("URL", (String) productObject.get("URL"));
		productmap.put("DeliveryPoint", (String) productObject.get("DeliveryPoint"));
		productmap.put("ProductMixture", (String) productObject.get("ProductMixture"));
		productmap.put("TransportMedium", (String) productObject.get("TransportMedium"));
		productmap.put("PaymentTerm", (String) productObject.get("PaymentTerm"));
		productmap.put("productName", (String) productObject.get("productName"));
		productName.add((String) productObject.get("productName"));
		productName.add((String) productObject.get("productName1"));
		productName.add((String) productObject.get("productName2"));
		productmap.put("qty", (String) productObject.get("qty"));
	}
	
	public void clearproduct() {
		
		productName.clear();
		System.out.println("Product array lists are cleared successfully");

}
}
