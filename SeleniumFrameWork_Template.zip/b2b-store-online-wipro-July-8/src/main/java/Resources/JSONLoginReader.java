package Resources;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.IReporter;

import EnvirnomentSetup.ConfigReader;

public class JSONLoginReader {

	public static String filepath = null;
	public static Map<String, String> loginmap = new HashMap<String, String>();
	public static FileReader freader=null;
	static JSONParser jsonParser =null;
	public static String region;
	public static String Env;

	
	

	public static void Reader()  {
		try {
			//Login Credentials 
			region=JSONReader.Region;
			String market = region.substring(0, 2);
			Env=JSONReader.Env;
			if(Env.equals("RCUAT"))
			{
			freader = new FileReader(".//TestData/LoginCredentials_RCUAT.json");
			JSONParser jsonParser = new JSONParser();
			Object obj = jsonParser.parse(freader);
			JSONArray login = (JSONArray) obj;

			// Iterate over product array
			login.forEach(log -> parseLogin((JSONObject) log));
			}
			else if(Env.equals("UAT"))
			{
			freader = new FileReader(".//TestData/LoginCredentials_UAT.json");
			JSONParser jsonParser = new JSONParser();
			Object obj = jsonParser.parse(freader);
			JSONArray login = (JSONArray) obj;

			// Iterate over product array
			login.forEach(log -> parseLogin((JSONObject) log));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Login Credentials !!!!");
			e.printStackTrace();
		}
		
	}
	private static void parseLogin(JSONObject login)
	{
		JSONObject loginObject = (JSONObject) login.get("B2BOnlineStore");
		loginmap.put("Email", (String) loginObject.get("Email"));
		loginmap.put("Password", (String) loginObject.get("Password"));
	}


}
