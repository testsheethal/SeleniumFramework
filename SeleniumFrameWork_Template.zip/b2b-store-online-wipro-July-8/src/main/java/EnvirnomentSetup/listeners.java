package EnvirnomentSetup;

import org.testng.*;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import ObjectRepository.Base;

public class listeners implements ITestListener {

	Base base = new Base();

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("Test Case Started !!! :" + "" +result.getName());

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		System.out.println("Successufully Executed :" + "" +result.getName());

	}

	@Override
	public void onTestFailure(ITestResult result) {
		// get a screenshot on failure
		base.getScreenshot(result.getName());

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub

	}

}
