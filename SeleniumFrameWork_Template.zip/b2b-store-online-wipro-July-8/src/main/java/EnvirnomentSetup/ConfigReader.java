package EnvirnomentSetup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ConfigReader {
	Properties pro;
	Properties pro1;

	public ConfigReader() {
		String path = System.getProperty("user.dir");
		File file = new File(path + "/src/main/java/ObjectRepository/BrowserSetting_Objects.properties");
		File file1 = new File(path + "/src/main/java/ObjectRepository/security.properties");
		try {
			FileInputStream FIS = new FileInputStream(file);
			pro = new Properties();
			pro.load(FIS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			FileInputStream FISS = new FileInputStream(file1);
			pro1 = new Properties();
			pro1.load(FISS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public String getSecretKey()
	{
		return pro1.getProperty("secretKey");
				
	}
	public String getSalt() {
		return pro1.getProperty("salt");
	}

	public String getEmailb2b() {
		return pro.getProperty("b2bonlineEmail");

	}

	public String getPassword() {
		return pro.getProperty("Password");

	}

	public String getBrowser() {
		return pro.getProperty("browser");
	}

	public String getchromePath() {
		return pro.getProperty("chromePath");
	}

	public String getMarket() {
		return pro.getProperty("Market");
	}

	public String cookiePopUp() {
		return pro.getProperty("cookiePopUp");
	}

	public String getLoginfailureMsg() {
		return pro.getProperty("Login_Failed");
	}

	public String getClientDiveryPointAndProductMixMsg() {
		return pro.getProperty("SelectClientDiveryPointAndProductMix");
	}

	public String getproductMixtureSearch() {
		return pro.getProperty("productMixtureSearch");
	}

	public String getAddProductToCartMsg() {
		return pro.getProperty("AddProductToCart");
	}

	public String getDeliveryPointSelect() {
		return pro.getProperty("DeliveryPointSelect");
	}

	public String ExcelError() {
		return pro.getProperty("ExcelError");
	}

	public String Session() {
		return pro.getProperty("Session");
	}

	public String ReorderMsg() {
		return pro.getProperty("ReorderMsg");
	}

	public String getemail() {
		return pro.getProperty("Login_email");
	}

	public String getpassword() {
		return pro.getProperty("Login_password");
	}

	public String getEnter() {
		return pro.getProperty("Login_Enter");
	}

	public String getClientClick() {
		return pro.getProperty("client_Click");
	}

	public String getSelectClient() {
		return pro.getProperty("selectClient");
	}

	public String getDeliveryClick() {
		return pro.getProperty("delivery_Click");
	}

	public String getSelectDelivery() {
		return pro.getProperty("selectDelivery");
	}

	public String getProductMixtureClick() {
		return pro.getProperty("productMixtureClick");
	}

	public String getProductMixtureSelect() {
		return pro.getProperty("productMixtureSelect");
	}

	public String addPurchaseOrderInHomePage() {
		return pro.getProperty("addPurchaseOrderInHomePage");
	}

	public String addPO() {
		return pro.getProperty("addPO");
	}

	// Shopping Cart Objects
	public String getgoCart() {
		return pro.getProperty("goCart");
	}

	// Home Page Objects
	public String getImportExcel() {
		return pro.getProperty("HomePage_ImportExcel");
	}

	// Add to Cart Import to Excel
	public String getDownloadlink() {
		return pro.getProperty("Download_Excel");
	}

	public String getClearCart() {
		return pro.getProperty("clearCart");
	}

	public String getcontinueBuying() {
		return pro.getProperty("continueBuying");
	}

	public String getProductLink() {
		return pro.getProperty("ProductLink");
	}

	public String getsearchProduct() {
		return pro.getProperty("searchProduct");
	}

	public String getproductList() {
		return pro.getProperty("productList");
	}

	public String getaddQty() {
		return pro.getProperty("addQty");
	}

	public String getaddToCart() {
		return pro.getProperty("addToCart");
	}

	public String getmoveToShoppingCart() {
		return pro.getProperty("moveToShoppingCart");
	}

	public String getverifyShoppingCartTitle() {
		return pro.getProperty("verifyShoppingCartTitle");
	}

	public String getaddPurchaseOrder() {
		return pro.getProperty("addPurchaseOrder");
	}

	public String getconfirmation_Popup() {
		return pro.getProperty("confirmation_Popup");
	}

	public String gettruckwrapper() {
		return pro.getProperty("truckwrapper");
	}

	public String getcheckOut() {
		return pro.getProperty("checkOut");
	}

	public String getBox() {
		return pro.getProperty("box");
	}

	public String getBox_EU() {
		return pro.getProperty("box_EU");
	}

	public String getBed() {
		return pro.getProperty("bed");
	}

	public String getPallet() {
		return pro.getProperty("pallet");
	}

	// Purchase Summary page
	public String getbillingSection() {
		return pro.getProperty("billingSection");
	}

	public String getdeliveryAddress() {
		return pro.getProperty("deliveryAddress");
	}

	public String getdeliveryDetails() {
		return pro.getProperty("deliveryDetails");
	}

	public String getexcelSummary() {
		return pro.getProperty("excelSummary");
	}

	public String getpdfSummary() {
		return pro.getProperty("pdfSummary");
	}

	public String getsubTotal() {
		return pro.getProperty("subTotal");
	}

	public String getagreementCheckbox() {
		return pro.getProperty("agreementCheckbox");
	}

	public String getmakeOrder() {
		return pro.getProperty("makeOrder");
	}

	public String getcheckPriceHeader() {
		return pro.getProperty("checkPriceHeader");
	}

	public String getarrivalDate() {
		return pro.getProperty("arrivalDate");
	}

	public String getshippingDate() {
		return pro.getProperty("shippingDate");
	}

	public String getsailDate() {
		return pro.getProperty("sailDate");
	}

	public String getverifyPriceSection() {
		return pro.getProperty("verifyPriceSection");
	}

	public String getsubTotalSection() {
		return pro.getProperty("subTotalSection");
	}

	public String gettaxSection() {
		return pro.getProperty("taxSection");
	}

	public String getgrandTotal() {
		return pro.getProperty("grandTotal");
	}

	public String getorderSuccessMessage() {
		return pro.getProperty("orderSuccessMessage");
	}

	public String getreturnStore() {
		return pro.getProperty("returnStore");
	}

	public String getgoOut() {
		return pro.getProperty("goOut");
	}

	public String getsaveShopping_List() {
		return pro.getProperty("saveShopping_List");
	}

	public String getshoppingList_Name() {
		return pro.getProperty("shoppingList_Name");
	}

	public String getsuccessMessage_SL() {
		return pro.getProperty("successMessage_SL");
	}

	public String getclick_Shoppinglist() {
		return pro.getProperty("click_Shoppinglist");
	}

	public String getlist_ProductsTablet() {
		return pro.getProperty("list_ProductsTable");
	}

	public String getshoppingList_addCart() {
		return pro.getProperty("shoppingList_addCart");
	}

	public String getremove_Cart() {
		return pro.getProperty("remove_Cart");
	}

	public String getaccountDropdown() {
		return pro.getProperty("accountDropdown");
	}

	public String countGoOut() {
		return pro.getProperty("goOut");
	}

	public String addPurchaseOrderinHomePage() {
		return pro.getProperty("addPurchaseOrderinHomePage");
	}

	public String purchaseOrderNumber() {
		return pro.getProperty("purchaseOrderNumber");
	}

	public String removeCartPopup() {
		return pro.getProperty("removeCartPopup");
	}

	public String SaveNameofShopping_List() {
		return pro.getProperty("SaveNameofShopping_List");
	}

	// Shopping List
	public String product_Verify1() {
		return pro.getProperty("product_Verify1");
	}

	public String product_Verify2() {
		return pro.getProperty("product_Verify2");
	}

	public String product_Verify3() {
		return pro.getProperty("product_Verify3");
	}

//order placing

	public String orderTracking() {
		return pro.getProperty("orderTracking");
	}

	public String selectDeliverypoint() {
		return pro.getProperty("selectDeliverypoint");
	}

	public String searchforDeliverypoint() {
		return pro.getProperty("searchforDeliverypoint");
	}

	public String checkboxDp() {
		return pro.getProperty("checkboxDp");
	}

	public String dateFilter() {
		return pro.getProperty("dateFilter");
	}

	public String dateRange() {
		return pro.getProperty("dateRange");
	}

	public String submitButton() {
		return pro.getProperty("submitButton");
	}

	public String orderHistoryTable() {
		return pro.getProperty("orderHistoryTable");
	}

	public String dataTableFilter() {
		return pro.getProperty("dataTableFilter");
	}

	public String verifyPurchaseOrder() {
		return pro.getProperty("verifyPurchaseOrder");
	}

	public String verifySAPId() {
		return pro.getProperty("verifySAPId");
	}

	public String clickReorder() {
		return pro.getProperty("clickReorder");
	}

	public String proceedPurchaseOrder() {
		return pro.getProperty("proceedPurchaseOrder");
	}

	public String verifyproduct1() {
		return pro.getProperty("verifyProduct1");
	}

	public String verifyproduct2() {
		return pro.getProperty("verifyProduct2");
	}

	public String AddtoCartExcelClose() {
		return pro.getProperty("AddtoCartExcelClose");
	}

	// Arrival date

	public String arrivaldisableddates() {
		return pro.getProperty("arrivaldisabledDates");
	}

	public String arrivalavailabledates() {
		return pro.getProperty("arrivalavailableDates");
	}

	// sail date

	public String saildisableddates() {
		return pro.getProperty("sailDisableddates");
	}

	public String sailavailabledates() {
		return pro.getProperty("sailAvailableDates");
	}

	// Shipping date

	public String shippingdisableddates() {
		return pro.getProperty("shippingDisableddates");
	}

	public String shippingavailabledates() {
		return pro.getProperty("shippingAvailableDates");
	}

	// CustomerOnlone Product Catalog

	public String myfavourites() {
		return pro.getProperty("myfavourites");
	}

	public String showProduct() {
		return pro.getProperty("showProduct");
	}

	public String sortBy() {
		return pro.getProperty("sortBy");
	}

	public String addtomyfavourites() {
		return pro.getProperty("addtomyfavourites");
	}

	public String removefavourites() {
		return pro.getProperty("removefavourites");
	}

	public String clearallfilters() {
		return pro.getProperty("clearallfilters");
	}

	public String verifytextallproducts() {
		return pro.getProperty("verifytextallproducts");
	}

	public String allProducts() {
		return pro.getProperty("allProducts");
	}

	// Add and Remove Shopping List

	public String shoppinglistRow1() {
		return pro.getProperty("shoppinglistRow1");
	}

	public String creationdateRow1() {
		return pro.getProperty("creationdateRow1");
	}

	public String createdbyRow1() {
		return pro.getProperty("createdbyRow1");
	}

	public String prodaddedtoPOsuccessmessage() {
		return pro.getProperty("prodaddedtoPOsuccessmessage");
	}

	public String removeshoppinglistsuccessmessage() {
		return pro.getProperty("removeshoppinglistsuccessmessage");
	}

	// Shopping Cart Preview

	public String removePO() {
		return pro.getProperty("removePO");
	}

	public String podeletionsuccessmessage() {
		return pro.getProperty("podeletionsuccessmessage");
	}

	public String chooseaction() {
		return pro.getProperty("chooseaction");
	}

	public String removeitem() {
		return pro.getProperty("removeitem");
	}

	public String confirmbutton() {
		return pro.getProperty("confirmbutton");
	}

	public String checkbox1() {
		return pro.getProperty("checkbox1");
	}

	public String addnewbutton() {
		return pro.getProperty("addnewbutton");
	}

	public String neworderbutton() {
		return pro.getProperty("neworderbutton");
	}

	public String enterodernumber() {
		return pro.getProperty("enterodernumber");
	}

	// Account Summary

	public String getAccountDetail_Title() {

		return pro.getProperty("AccountDetail_Title");

	}

	public String getAccountDetail_FirstName() {

		return pro.getProperty("AccountDetail_FirstName");

	}

	public String getFirstName_Displayed() {

		return pro.getProperty("FirstName_Displayed");

	}

	public String getAccountDetail_SurName() {

		return pro.getProperty("AccountDetail_SurName");

	}

	public String getSurName_Displayed() {

		return pro.getProperty("SurName_Displayed");

	}

	public String getAccountDetail_Email() {

		return pro.getProperty("AccountDetail_Email");

	}

	public String getEmail_Displayed() {

		return pro.getProperty("Email_Displayed");

	}

	public String getAccountDetail_UserType() {

		return pro.getProperty("AccountDetail_UserType");

	}

	public String getUserType_Displayed() {

		return pro.getProperty("UserType_Displayed");

	}

	public String getChangePassword_Title() {

		return pro.getProperty("ChangePassword_Title");

	}

	public String getCurrentPassword_TextBox() {

		return pro.getProperty("CurrentPassword_TextBox");

	}

	public String getNewPassword_TextBox() {

		return pro.getProperty("NewPassword_TextBox");

	}

	public String getConfirmPassword_TextBox() {

		return pro.getProperty("ConfirmPassword_TextBox");

	}

	public String getSavePassword_Button() {

		return pro.getProperty("SavePassword_Button");

	}

	// Default Excel

	public String getDefaultExcelBox() {

		return pro.getProperty("DefaultExcelBox");

	}

	public String getCustomExcelBOx() {

		return pro.getProperty("CustomExcelBOx");

	}

	public String getUpload_DefaultExcel() {

		return pro.getProperty("Upload_DefaultExcel");

	}

	public String getSuccess_Popup() {

		return pro.getProperty("Success_Popup");

	}

	public String getSuccess_Message() {

		return pro.getProperty("Success_Message");

	}

	public String getSuccess_Closebutton() {

		return pro.getProperty("Success_Closebutton");

	}

	// Customer Excel

	public String getConfigure_Excel() {

		return pro.getProperty("Configure_Excel");

	}

	public String getFileConfigure_SheetName() {

		return pro.getProperty("FileConfigure_SheetName");

	}

	public String getFileConfigure_IndexofRow() {

		return pro.getProperty("FileConfigure_IndexofRow");

	}

	public String getFileConfigure_ProductCode() {

		return pro.getProperty("FileConfigure_ProductCode");

	}

	public String getFileConfigure_NameofQuantity() {

		return pro.getProperty("FileConfigure_NameofQuantity");

	}

	public String getFileConfigure_NameofMeasure() {

		return pro.getProperty("FileConfigure_NameofMeasure");

	}

	public String getFileConfigure_BoxName() {

		return pro.getProperty("FileConfigure_BoxName");

	}

	public String getFileConfigure_BedName() {

		return pro.getProperty("FileConfigure_BedName");

	}

	public String getFileConfigure_PalletName() {

		return pro.getProperty("FileConfigure_PalletName");

	}

	public String getFileConfigure_SaveButton() {

		return pro.getProperty("FileConfigure_SaveButton");

	}

	public String getFileConfigure_BacktoScreen() {

		return pro.getProperty("FileConfigure_BacktoScreen");

	}

	public String getUploadExcel() {

		return pro.getProperty("UploadExcel");

	}

	// Customer Online Home Page

	public String getHomePage_AccountMenu() {

		return pro.getProperty("HomePage_AccountMenu");

	}

	public String getHomePage_AccountDetails() {

		return pro.getProperty("HomePage_AccountDetails");

	}

	public String getHomePage_MyFavorites() {

		return pro.getProperty("HomePage_MyFavorites");

	}

	public String getHomePage_DeliveryPoints() {

		return pro.getProperty("HomePage_DeliveryPoints");

	}

	public String getDeliveryPointTitle() {

		return pro.getProperty("DeliveryPointTitle");

	}

	public String getPglogo() {

		return pro.getProperty("Pglogo");

	}

	public String getHomePage_Image() {

		return pro.getProperty("HomePage_Image");

	}

	public String getHomePage_FrequentQuestion() {

		return pro.getProperty("HomePage_FrequentQuestion");

	}

	public String getHomePage_TermsCondition() {

		return pro.getProperty("HomePage_TermsCondition");

	}

	public String getHomePage_Privacy() {

		return pro.getProperty("HomePage_Privacy");

	}

	public String getHomePage_Cookies() {

		return pro.getProperty("HomePage_Cookies");

	}

	public String getHomePage_AdChoices() {

		return pro.getProperty("HomePage_AdChoices");

	}

	public String getHomePage_Search() {

        return pro.getProperty("HomePage_Search");

  }

  public String getHomePage_SearchButton() {

        return pro.getProperty("HomePage_SearchButton");

  }
}
