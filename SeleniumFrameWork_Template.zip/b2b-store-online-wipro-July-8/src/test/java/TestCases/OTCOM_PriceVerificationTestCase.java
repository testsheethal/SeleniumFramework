package TestCases;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Components.OAB2B_Login;
import EnvirnomentSetup.ConfigReader;
import ObjectRepository.Base;
import Resources.JSONReader;
import junit.framework.Assert;

import java.io.IOException;

public class OTCOM_PriceVerificationTestCase extends Base 
{
	ConfigReader reader = new ConfigReader();
	JSONReader jreader = new JSONReader();
	
	@Test
	
	public void PriceVerification() throws IOException, InterruptedException {
		try {
			driver = (RemoteWebDriver) initialiseDriver();
			driver.manage().window().maximize();
			System.out.println("OTCOM_PriceVerificationTestCase..!");
			OAB2B_Login PandGlogin = new OAB2B_Login(driver);
			waitForPage();
			PandGlogin.Login();
			waitForPage();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(reader.getLoginfailureMsg());
		}
	}
		
	  @AfterTest
	  public void tearDown()
	  {
		  jreader.clearproduct();
		 
		  driver.quit(); 
		 }
	  

}
